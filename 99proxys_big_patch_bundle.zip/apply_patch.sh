#!/usr/bin/env bash
set -euo pipefail
PATCH_FILE="${1:-99proxys_big_fix.patch}"
ROOT="${2:-.}"
command -v patch >/dev/null 2>&1 || { echo "[!] 'patch' tool not found on PATH"; exit 2; }
echo "[i] Dry run..."
patch --dry-run -p0 -d "$ROOT" < "$PATCH_FILE"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP="${ROOT%/}.bak.${TS}"
echo "[i] Backing up to $BACKUP ..."
cp -r "$ROOT" "$BACKUP"
echo "[i] Applying patch..."
patch -p0 -d "$ROOT" < "$PATCH_FILE"
echo "[✓] Done. Backup at $BACKUP"
