# 99Proxys v4.5.5b

This repository contains an enhanced version of **99Proxys**, a local VPN/tor‑like proxy network originally implemented in Python.  Version **4.5.5b** introduces a multi‑language architecture by incorporating native C/C++ modules and an optional Java utility alongside the Python codebase.  These improvements aim to increase performance and security while preserving all original features.

## Contents

```
99proxys_v4.5.5b/
├── aes_module.c            # C implementation of AES‑256‑CBC encryption
├── proxy_relay.cpp         # C++ epoll‑based relay skeleton for proxy traffic
├── CertificateGenerator.java # Java utility to generate self‑signed certificates and private keys
├── native_crypto.py        # Python wrapper for aes_module.c with fallback to cryptography
├── native_relay.py         # Python wrapper for proxy_relay.cpp with fallback to pure Python
├── 99proxys_v4-5b.py       # Original Python implementation of 99Proxys
├── tor_emulation.py        # Self‑contained onion‑routing module for Tor‑like circuits
├── docs/
│   └── refined_99proxys_multilanguage.md # Detailed design and integration guide
└── README.md               # This file
```

## Building the Native Modules

Before running the Python application with native enhancements, you must compile the C and C++ sources.  These commands assume a Linux host with GCC, G++, and OpenSSL development headers installed.  Adjust the commands for other platforms as necessary.

```bash
# Build the AES encryption library
gcc -fPIC -shared -o libaes.so aes_module.c -lcrypto

# Build the proxy relay library
g++ -fPIC -shared -o librelay.so proxy_relay.cpp

# Optionally, build the Java certificate generator
javac CertificateGenerator.java
```

Copy the resulting `libaes.so` and `librelay.so` into the same directory as `native_crypto.py` and `native_relay.py`.  If you wish to generate SSL certificates via Java, run `java CertificateGenerator <cert_file> <key_file>`.

### Interactive Installer Scripts

To simplify setup, this package includes cross‑platform installer
scripts that guide you through the process with yes/no prompts.  They
will build the native modules, optionally compile the Java utility,
install Python dependencies, and—if desired—copy the project into a
standard system location with launcher shortcuts.

* **Linux:** run `install_linux.sh` from the project root.  The
  script prompts you for each step and can relaunch itself via `sudo`
  when it needs administrative privileges.  It offers to compile the
  C/C++ libraries (`libaes.so`, `librelay.so`), compile the Java
  certificate generator, install packages from `requirements.txt`,
  copy the project into a directory of your choosing (default
  `/opt/99Proxys`), and create a launcher at `/usr/local/bin/99proxys`.

* **Windows:** run `install_windows.bat` from an elevated command
  prompt (right‑click and choose "Run as administrator").  The
  installer will ask whether to build `libaes.dll` and `librelay.dll`,
  compile `CertificateGenerator.java`, install Python packages via
  pip, copy files to an installation directory (default
  `%ProgramFiles%\99Proxys`), and create desktop and Start Menu
  shortcuts using PowerShell.  The script attempts to use MinGW
  (`gcc`/`g++`) first and falls back to MSVC (`cl`).

Follow the prompts to customise the installation to your needs.  After
completing the installer, you can start 99Proxys using the usual
Python commands described below or via the created launcher/shortcuts.

## Using the Python Application

The main entry point remains `99proxys_v4-5b.py`, which can be run in three modes:

1. **Graphical interface** (default):
   ```bash
   python3 99proxys_v4-5b.py
   ```
2. **Command‑line interface**:
   ```bash
   python3 99proxys_v4-5b.py --cli
   ```
3. **Unit testing**:
   ```bash
   python3 99proxys_v4-5b.py --test
   ```

By default, the Python code uses the original Fernet encryption and pure‑Python socket handling.  When the compiled native libraries are present in the same directory, the wrappers in `native_crypto.py` and `native_relay.py` will automatically load them and provide high‑performance cryptography and packet relay.  If loading fails, the wrappers silently fall back to the Python implementations, ensuring the system remains functional.

## Documentation

The `docs/refined_99proxys_multilanguage.md` file contains a comprehensive discussion of the multi‑language architecture, including design rationale, detailed code samples, security considerations, and integration instructions.  Consult this document for deeper insight into how the new modules interact with the existing system.

## Security Notes

While these native modules improve performance and allow constant‑time cryptography, you should still audit and harden the code before deploying it in a production environment.  Consider containerizing each proxy node for isolation, enforcing input validation, rate limiting, and writing structured logs for monitoring.

## Tor‑Style Onion Routing

This release includes an experimental module, `tor_emulation.py`, that
implements the core ideas of onion routing in a standalone
fashion.  You can use it to build multi‑hop circuits out of simulated
nodes, each with its own AES key, IP address and MAC address.  The
module provides functions to wrap data in successive encryption layers
and unwrap it hop by hop, closely mirroring the Tor protocol.  To
create a circuit from the built‑in locale definitions, call
`CircuitManager.from_locales()` and specify the desired hop count.  For
detailed usage, see the extensive docstring at the top of
`tor_emulation.py`.