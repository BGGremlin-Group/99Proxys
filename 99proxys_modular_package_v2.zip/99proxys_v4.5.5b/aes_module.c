// aes_module.c
//
// This module provides high‑performance AES‑256‑CBC encryption routines
// using OpenSSL.  It exposes a minimal C API that can be used from
// Python via ctypes or cffi.  The functions perform context
// initialization, block updates, and finalization (handling padding).

#include <openssl/evp.h>
#include <openssl/rand.h>
#include <stdlib.h>
#include <string.h>

/*
 * Initialize an AES‑256‑CBC encryption context.  The caller must provide
 * a 32‑byte key and a 16‑byte IV.  The returned pointer must be freed
 * by calling aes_encrypt_final().
 */
EVP_CIPHER_CTX *aes_encrypt_init(const unsigned char *key,
                                 const unsigned char *iv) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        return NULL;
    }
    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return NULL;
    }
    return ctx;
}

/*
 * Encrypt a block of data.  `plaintext` and `ciphertext` may point
 * to overlapping buffers as long as ciphertext is large enough to
 * hold the result.  Returns the number of bytes written to
 * ciphertext, or -1 on error.
 */
int aes_encrypt_update(EVP_CIPHER_CTX *ctx,
                       const unsigned char *plaintext,
                       int plaintext_len,
                       unsigned char *ciphertext) {
    int len = 0;
    if (!ctx || !plaintext || !ciphertext) {
        return -1;
    }
    if (EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len) != 1) {
        return -1;
    }
    return len;
}

/*
 * Finalize encryption.  This handles PKCS#7 padding and frees the
 * encryption context.  The caller must provide a buffer large
 * enough to hold any remaining ciphertext (at most one block size).
 * Returns the number of bytes written, or -1 on error.
 */
int aes_encrypt_final(EVP_CIPHER_CTX *ctx, unsigned char *ciphertext) {
    int len = 0;
    if (!ctx || !ciphertext) {
        return -1;
    }
    if (EVP_EncryptFinal_ex(ctx, ciphertext, &len) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }
    EVP_CIPHER_CTX_free(ctx);
    return len;
}

/*
 * Initialize an AES‑256‑CBC decryption context.  The caller must provide
 * the same key and IV used for encryption.  The returned pointer must
 * be freed via aes_decrypt_final().
 */
EVP_CIPHER_CTX *aes_decrypt_init(const unsigned char *key,
                                 const unsigned char *iv) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        return NULL;
    }
    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return NULL;
    }
    return ctx;
}

/*
 * Decrypt a block of data.  Returns the number of bytes written to
 * plaintext, or -1 on error.  Note that ciphertext_len must be a
 * multiple of the block size (16) except for the final block.
 */
int aes_decrypt_update(EVP_CIPHER_CTX *ctx,
                       const unsigned char *ciphertext,
                       int ciphertext_len,
                       unsigned char *plaintext) {
    int len = 0;
    if (!ctx || !ciphertext || !plaintext) {
        return -1;
    }
    if (EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
        return -1;
    }
    return len;
}

/*
 * Finalize decryption and free the context.  Writes any remaining
 * plaintext (after removing padding) to the provided buffer.
 */
int aes_decrypt_final(EVP_CIPHER_CTX *ctx, unsigned char *plaintext) {
    int len = 0;
    if (!ctx || !plaintext) {
        return -1;
    }
    if (EVP_DecryptFinal_ex(ctx, plaintext, &len) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }
    EVP_CIPHER_CTX_free(ctx);
    return len;
}