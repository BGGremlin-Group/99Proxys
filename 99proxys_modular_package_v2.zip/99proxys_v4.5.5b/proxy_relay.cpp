// proxy_relay.cpp
//
// This file contains a simplified high‑performance proxy relay using
// epoll.  It is designed to forward traffic efficiently between two
// file descriptors (typically sockets) without blocking.  In a
// production system this would be expanded to manage multiple
// connections concurrently, implement rate limiting and TLS, and
// collect detailed statistics.  The functions here expose a C
// interface for consumption from Python.

#include <sys/epoll.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

extern "C" {

/*
 * Relay data from `fd_in` to `fd_out` using a simple read/write
 * loop.  Returns the number of bytes relayed, or -1 on error.
 */
ssize_t relay_once(int fd_in, int fd_out) {
    char buffer[4096];
    ssize_t bytes = read(fd_in, buffer, sizeof(buffer));
    if (bytes <= 0) {
        return bytes; // 0 indicates EOF, negative indicates error
    }
    ssize_t total = 0;
    while (total < bytes) {
        ssize_t written = write(fd_out, buffer + total, (size_t)(bytes - total));
        if (written <= 0) {
            return -1;
        }
        total += written;
    }
    return bytes;
}

/*
 * Placeholder for a full epoll‑based relay.  In a complete
 * implementation this would accept two sockets, register them
 * with an epoll instance, and forward data in both directions
 * asynchronously.  For demonstration, this function simply
 * proxies data until one side closes.
 */
int relay_bidirectional(int fd_a, int fd_b) {
    const int MAX_EVENTS = 2;
    int epoll_fd = epoll_create1(0);
    if (epoll_fd < 0) {
        return -1;
    }
    struct epoll_event ev, events[MAX_EVENTS];
    ev.events = EPOLLIN;
    ev.data.fd = fd_a;
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, fd_a, &ev) < 0) {
        close(epoll_fd);
        return -1;
    }
    ev.data.fd = fd_b;
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, fd_b, &ev) < 0) {
        close(epoll_fd);
        return -1;
    }
    char buf[4096];
    for (;;) {
        int nfds = epoll_wait(epoll_fd, events, MAX_EVENTS, -1);
        if (nfds < 0) {
            if (errno == EINTR) continue;
            break;
        }
        for (int i = 0; i < nfds; i++) {
            int src = events[i].data.fd;
            int dst = (src == fd_a ? fd_b : fd_a);
            ssize_t n = read(src, buf, sizeof(buf));
            if (n <= 0) {
                close(epoll_fd);
                return 0; // closed or error
            }
            ssize_t sent = 0;
            while (sent < n) {
                ssize_t w = write(dst, buf + sent, (size_t)(n - sent));
                if (w <= 0) {
                    close(epoll_fd);
                    return -1;
                }
                sent += w;
            }
        }
    }
    close(epoll_fd);
    return 0;
}

} // extern "C"