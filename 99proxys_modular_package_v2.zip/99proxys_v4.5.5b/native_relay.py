"""
native_relay.py
================

This module wraps the native proxy relay functions provided by the
``proxy_relay.cpp`` shared library.  The native library must be
compiled into ``librelay.so`` (on Linux) or ``librelay.dll`` (on
Windows) before use.  If the library cannot be loaded, this module
provides a simple Python fallback using blocking sockets.
"""
import ctypes
import os
import socket

try:
    import select  # Used in Python fallback
except ImportError:
    select = None

# Attempt to load native relay library
try:
    _lib_path = os.path.join(os.path.dirname(__file__), {
        os.name == 'nt': 'librelay.dll',
        os.name != 'nt': 'librelay.so'
    }[True])
    _native = ctypes.CDLL(_lib_path)
    _native.relay_once.restype = ctypes.c_ssize_t
    _native.relay_once.argtypes = [ctypes.c_int, ctypes.c_int]
    _native.relay_bidirectional.restype = ctypes.c_int
    _native.relay_bidirectional.argtypes = [ctypes.c_int, ctypes.c_int]
    USE_NATIVE_RELAY = True
except Exception:
    USE_NATIVE_RELAY = False


def relay_once(sock_in: socket.socket, sock_out: socket.socket) -> int:
    """
    Relay a single chunk of data from ``sock_in`` to ``sock_out``.
    Returns the number of bytes forwarded, 0 on EOF, or -1 on error.
    Uses the native C implementation if available, otherwise
    performs a blocking read/write in Python.
    """
    if USE_NATIVE_RELAY:
        fd_in = sock_in.fileno()
        fd_out = sock_out.fileno()
        return _native.relay_once(fd_in, fd_out)
    else:
        try:
            data = sock_in.recv(4096)
            if not data:
                return 0
            total = 0
            while total < len(data):
                sent = sock_out.send(data[total:])
                if sent == 0:
                    return -1
                total += sent
            return total
        except Exception:
            return -1


def relay_bidirectional(sock_a: socket.socket, sock_b: socket.socket) -> int:
    """
    Relay traffic in both directions between two sockets.  This call
    blocks until either socket closes.  Uses the native C++ epoll
    implementation if available; otherwise falls back to a simple
    Python loop.
    """
    if USE_NATIVE_RELAY:
        fd_a = sock_a.fileno()
        fd_b = sock_b.fileno()
        return _native.relay_bidirectional(fd_a, fd_b)
    else:
        try:
            sock_a.setblocking(False)
            sock_b.setblocking(False)
            inputs = [sock_a, sock_b]
            outputs = {sock_a: sock_b, sock_b: sock_a}
            while True:
                readable, _, _ = select.select(inputs, [], [])
                for s in readable:
                    other = outputs[s]
                    data = s.recv(4096)
                    if not data:
                        return 0
                    total = 0
                    while total < len(data):
                        sent = other.send(data[total:])
                        if sent == 0:
                            return -1
                        total += sent
        except Exception:
            return -1