"""
tor_emulation.py
=================

This module introduces a simple onion‑routing framework for 99Proxys.  It is
designed to emulate the core behaviours of the Tor network within a
controlled local environment.  A circuit is a sequence of `TorNode`
instances, each with its own cryptographic key and simulated network
identity (MAC address, IP address and locale).  When a message is sent
through a circuit, it is wrapped in multiple layers of encryption—one
layer per node—so that each hop can only remove its own layer and learn
the next destination.  This provides strong anonymity for the client
within the local 99Proxys network.

This implementation is intentionally self‑contained and does not
interfere with the existing proxy management infrastructure.  You can
import `CircuitManager` into your own scripts or extend the main
application to build and use circuits for Tor‑like traffic routing.

Usage example:

>>> from tor_emulation import CircuitManager, TorNode
>>> # Define available nodes with unique identity information
>>> nodes = [
...     TorNode(country="United States", ip="10.0.0.2", mac="00:0D:3F:01:02:03"),
...     TorNode(country="Germany", ip="10.0.0.3", mac="00:16:6C:04:05:06"),
...     TorNode(country="Japan", ip="10.0.0.4", mac="00:24:E4:07:08:09"),
... ]
>>> mgr = CircuitManager(nodes)
>>> circuit = mgr.build_circuit(3)  # select three random hops
>>> payload = b"Hello, world!"
>>> onion = circuit.wrap(payload)   # client encrypts with layered keys
>>> response = circuit.unwrap(onion) # each hop removes one layer
>>> assert response == payload

Note:  This module uses the `cryptography` package for AES‑256‑CBC
encryption.  If the native AES module (`native_crypto.AESCipher`) is
available in the project, you can adjust the implementation to use
constant‑time encryption.
"""

from __future__ import annotations

import os
import random
from dataclasses import dataclass
from typing import List

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding as sym_padding


def generate_key() -> bytes:
    """Generate a 32‑byte AES key."""
    return os.urandom(32)


def generate_iv() -> bytes:
    """Generate a 16‑byte IV for AES‑CBC."""
    return os.urandom(16)


def aes_encrypt(key: bytes, iv: bytes, plaintext: bytes) -> bytes:
    """
    Encrypt data using AES‑256‑CBC with PKCS7 padding.

    Args:
        key: 32‑byte encryption key.
        iv: 16‑byte initialization vector.
        plaintext: Data to encrypt.

    Returns:
        Encrypted ciphertext.
    """
    backend = default_backend()
    padder = sym_padding.PKCS7(128).padder()
    padded = padder.update(plaintext) + padder.finalize()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
    encryptor = cipher.encryptor()
    return encryptor.update(padded) + encryptor.finalize()


def aes_decrypt(key: bytes, iv: bytes, ciphertext: bytes) -> bytes:
    """
    Decrypt data using AES‑256‑CBC with PKCS7 padding removal.

    Args:
        key: 32‑byte decryption key.
        iv: 16‑byte initialization vector.
        ciphertext: Data to decrypt.

    Returns:
        Decrypted plaintext.
    """
    backend = default_backend()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
    decryptor = cipher.decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()
    unpadder = sym_padding.PKCS7(128).unpadder()
    return unpadder.update(padded) + unpadder.finalize()


@dataclass
class TorNode:
    """
    Represents a node in the Tor‑like circuit with its own symmetric key
    and network identity.

    Attributes:
        country (str): Human‑readable country/region identifier.
        ip (str): Simulated IP address for the node.
        mac (str): Simulated MAC address for the node.
        key (bytes): 32‑byte AES key used for encryption/decryption.
    """

    country: str
    ip: str
    mac: str
    key: bytes = None

    def __post_init__(self):
        if self.key is None:
            self.key = generate_key()


class Circuit:
    """
    A sequence of TorNodes forming an onion‑routing circuit.  The
    circuit holds a snapshot of the ordered nodes and can wrap and
    unwrap payloads accordingly.  Encryption happens from the last
    node to the first, while decryption happens in the opposite order.
    """

    def __init__(self, nodes: List[TorNode]):
        if len(nodes) < 1:
            raise ValueError("A circuit must contain at least one node")
        self.nodes = nodes

    def wrap(self, data: bytes) -> bytes:
        """
        Wrap (encrypt) data in successive AES layers for each node in
        reverse order (from exit to entry).  Each layer consists of
        IV||ciphertext, where IV is 16 bytes.

        Args:
            data: The plaintext payload to wrap.

        Returns:
            The onion‑wrapped payload as bytes.
        """
        payload = data
        for node in reversed(self.nodes):
            iv = generate_iv()
            payload = iv + aes_encrypt(node.key, iv, payload)
        return payload

    def unwrap(self, onion: bytes) -> bytes:
        """
        Unwrap (decrypt) an onion‑wrapped payload.  Each layer is
        processed in forward order, removing one encryption layer per
        node.

        Args:
            onion: The wrapped payload produced by `wrap()`.

        Returns:
            The original plaintext after all layers are removed.
        """
        payload = onion
        for node in self.nodes:
            if len(payload) < 16:
                raise ValueError("Invalid onion payload: missing IV")
            iv, ciphertext = payload[:16], payload[16:]
            payload = aes_decrypt(node.key, iv, ciphertext)
        return payload


class CircuitManager:
    """
    Manages a pool of TorNodes and constructs random circuits from
    them.  You can add nodes manually or initialize from the 99Proxys
    locale list.  When building a circuit, a specified number of
    distinct nodes are selected at random.
    """

    def __init__(self, nodes: List[TorNode]):
        if not nodes:
            raise ValueError("CircuitManager requires at least one node")
        self.nodes = nodes

    @classmethod
    def from_locales(cls, locales: List[dict], count: int = 3) -> 'CircuitManager':
        """
        Create a CircuitManager from the LOCALES definition used in
        99Proxys.  Each locale entry must contain `country` and
        `ip_prefix`.  A random IP within the prefix and a simulated MAC
        address are generated for each node.

        Args:
            locales: List of locale dictionaries from 99Proxys.
            count: Number of nodes to create (defaults to 3).

        Returns:
            CircuitManager with the generated nodes.
        """
        def random_ip(prefix: str) -> str:
            network = prefix.split('/')
            base = network[0].rsplit('.', 1)[0]
            host = random.randint(2, 254)
            return f"{base}.{host}"

        def random_mac(oui: str) -> str:
            # Generate a MAC address by appending three random bytes to the OUI
            return oui + ":" + ":".join(f"{random.randint(0, 255):02x}" for _ in range(3))

        selected_locales = random.sample(locales, min(count, len(locales)))
        nodes: List[TorNode] = []
        for loc in selected_locales:
            ip = random_ip(loc['ip_prefix']) if 'ip_prefix' in loc else f"10.0.0.{random.randint(2, 254)}"
            # Use a fixed IoT OUI pool for MAC generation; fallback to random values
            oui_list = ["00:0D:3F", "00:16:6C", "00:24:E4", "00:1E:C0", "00:26:66", "00:1A:22", "00:17:88", "00:21:CC", "00:24:81", "00:1D:0F"]
            oui = random.choice(oui_list)
            mac = random_mac(oui)
            nodes.append(TorNode(country=loc['country'], ip=ip, mac=mac))
        return cls(nodes)

    def build_circuit(self, hop_count: int) -> Circuit:
        """
        Construct a circuit with a specific number of hops by sampling
        distinct nodes from the manager's pool.  If `hop_count` is
        greater than the available nodes, all nodes are used.

        Args:
            hop_count: Desired number of nodes in the circuit.

        Returns:
            Circuit instance.
        """
        if hop_count <= 0:
            raise ValueError("hop_count must be positive")
        nodes = random.sample(self.nodes, min(hop_count, len(self.nodes)))
        return Circuit(nodes)