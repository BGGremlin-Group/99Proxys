#!/bin/bash
#
# install_linux.sh
#
# Interactive installer for 99Proxys v4.5.5b on Linux.  This script
# guides the user through building the native C/C++ modules, compiling the
# Java certificate generator, installing Python dependencies, and
# optionally copying the project into a system‑wide location and
# creating a convenient launcher.  It attempts to obtain
# administrative privileges when needed.  Run this script from the
# project root.

set -euo pipefail

# Prompt the user with a yes/no question.  Accepts an optional default
# answer ("Y" or "N").  Returns 0 on yes, 1 on no.
prompt_yes_no() {
    local prompt="$1"
    local default_answer="${2:-Y}"
    local reply
    while true; do
        if [[ "$default_answer" =~ ^[Yy]$ ]]; then
            read -r -p "$prompt [Y/n] " reply
            reply=${reply:-Y}
        else
            read -r -p "$prompt [y/N] " reply
            reply=${reply:-N}
        fi
        case "${reply}" in
            [Yy]* ) return 0;;
            [Nn]* ) return 1;;
            * ) echo "Please answer yes or no.";;
        esac
    done
}

# Ensure we have administrative privileges for system‑wide actions.  If
# not, offer to relaunch with sudo.  When running as root this is a no‑op.
require_admin() {
    if [[ "$EUID" -ne 0 ]]; then
        echo "This installer must be run with administrative privileges for certain steps."
        if prompt_yes_no "Would you like to restart this script using sudo?"; then
            exec sudo "$0" "$@"
            exit 0
        else
            echo "Cannot proceed without administrative privileges.  Exiting."
            exit 1
        fi
    fi
}

echo "\n=== 99Proxys v4.5.5b Installer ===\n"
echo "This wizard will help you build the native modules, install Python dependencies,"
echo "and copy 99Proxys into a system location.  You may skip any step.\n"

# Offer to build the AES encryption library
if prompt_yes_no "Build the AES encryption library (libaes.so)?" "Y"; then
    echo "[+] Building AES encryption library (libaes.so)"
    gcc -fPIC -shared -o libaes.so aes_module.c -lcrypto
else
    echo "[+] Skipping AES library build"
fi

# Offer to build the relay library
if prompt_yes_no "Build the relay library (librelay.so)?" "Y"; then
    echo "[+] Building relay library (librelay.so)"
    g++ -fPIC -shared -o librelay.so proxy_relay.cpp
else
    echo "[+] Skipping relay library build"
fi

# Offer to compile the Java certificate generator if javac is available
if command -v javac >/dev/null 2>&1; then
    if prompt_yes_no "Compile the Java certificate generator (CertificateGenerator.java)?" "Y"; then
        echo "[+] Compiling Java certificate generator"
        javac CertificateGenerator.java
    else
        echo "[+] Skipping Java compilation"
    fi
else
    echo "[!] javac not found; skipping Java certificate generator build"
fi

# Offer to install Python dependencies
if prompt_yes_no "Install Python dependencies from requirements.txt?" "Y"; then
    echo "[+] Updating pip and installing Python dependencies"
    python3 -m pip install --upgrade pip
    if [[ -f requirements.txt ]]; then
        python3 -m pip install -r requirements.txt
    else
        echo "[-] requirements.txt not found; skipping pip install"
    fi
else
    echo "[+] Skipping Python dependency installation"
fi

# Offer to copy files to system directory
if prompt_yes_no "Copy project files to a system installation directory?" "Y"; then
    require_admin "$@"
    default_install_dir="/opt/99Proxys"
    read -r -p "Enter installation directory [${default_install_dir}]: " install_dir
    install_dir=${install_dir:-$default_install_dir}
    echo "[+] Copying project files to ${install_dir}"
    mkdir -p "$install_dir"
    # Copy everything except the installation scripts themselves and the docs directory separately
    rsync -a --exclude='docs' ./ "$install_dir/"
    echo "[+] Project files copied"
    # Offer to create a launcher script in /usr/local/bin
    if prompt_yes_no "Create a system‑wide launcher script (/usr/local/bin/99proxys)?" "Y"; then
        launcher="/usr/local/bin/99proxys"
        cat > "$launcher" <<'LAUNCHER'
#!/bin/bash
# Simple wrapper to launch 99Proxys from its installation directory
exec python3 /opt/99Proxys/99proxys_v4-5b.py "$@"
LAUNCHER
        chmod +x "$launcher"
        echo "[+] Launcher created at /usr/local/bin/99proxys"
    fi
fi

echo "\n[+] Installation steps complete.  You can now run 99Proxys via:\n    python3 99proxys_v4-5b.py\n"