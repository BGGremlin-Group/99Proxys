"""
native_crypto.py
=================

This module loads the native AES encryption library (``libaes.so`` or
``libaes.dll``) built from ``aes_module.c`` and provides a Python
wrapper class, :class:`AESCipher`, that matches the interface used in
the Python‐only implementation.  If the native library cannot be
loaded, a fallback implementation based on the ``cryptography``
package is used instead.

To compile the C library on Linux, run:

    gcc -fPIC -shared -o libaes.so aes_module.c -lcrypto

Place the resulting shared library in the same directory as this
module or adjust the load path accordingly.
"""
import ctypes
import os
import threading

try:
    # Attempt to locate and load the native library.  This assumes
    # libaes.so (Linux) or libaes.dll (Windows) resides in the same
    # directory as this Python file.
    _lib_path = os.path.join(os.path.dirname(__file__), {
        os.name == 'nt': 'libaes.dll',
        os.name != 'nt': 'libaes.so'
    }[True])
    _native_lib = ctypes.CDLL(_lib_path)

    # Define argument and return types for native functions
    _native_lib.aes_encrypt_init.restype = ctypes.c_void_p
    _native_lib.aes_encrypt_init.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    _native_lib.aes_encrypt_update.restype = ctypes.c_int
    _native_lib.aes_encrypt_update.argtypes = [ctypes.c_void_p,
                                              ctypes.c_char_p,
                                              ctypes.c_int,
                                              ctypes.c_char_p]
    _native_lib.aes_encrypt_final.restype = ctypes.c_int
    _native_lib.aes_encrypt_final.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

    # Decryption functions
    _native_lib.aes_decrypt_init.restype = ctypes.c_void_p
    _native_lib.aes_decrypt_init.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    _native_lib.aes_decrypt_update.restype = ctypes.c_int
    _native_lib.aes_decrypt_update.argtypes = [ctypes.c_void_p,
                                               ctypes.c_char_p,
                                               ctypes.c_int,
                                               ctypes.c_char_p]
    _native_lib.aes_decrypt_final.restype = ctypes.c_int
    _native_lib.aes_decrypt_final.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    USE_NATIVE = True
except Exception as e:
    # Fall back to pure Python implementation using cryptography
    USE_NATIVE = False

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

class AESCipher:
    """Unified AES‑256‑CBC encryption.  Uses native code if available."""
    def __init__(self, key: bytes, iv: bytes):
        if len(key) != 32 or len(iv) != 16:
            raise ValueError("Key must be 32 bytes and IV must be 16 bytes")
        self.key = key
        self.iv = iv
        if USE_NATIVE:
            # Initialize native encryption and decryption contexts
            self._ctx_enc = _native_lib.aes_encrypt_init(key, iv)
            self._ctx_dec = _native_lib.aes_decrypt_init(key, iv)
            if not self._ctx_enc or not self._ctx_dec:
                raise OSError("Failed to initialize native AES context")
            self._lock = threading.Lock()
        else:
            # Set up Python cryptography context
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
            self._encryptor = cipher.encryptor()
            self._decryptor = cipher.decryptor()
            self._lock = threading.Lock()

    def encrypt_update(self, data: bytes) -> bytes:
        """Encrypt a chunk of data and return ciphertext."""
        if not data:
            return b''
        with self._lock:
            if USE_NATIVE:
                out = ctypes.create_string_buffer(len(data) + 16)
                n = _native_lib.aes_encrypt_update(self._ctx_enc, data, len(data), out)
                if n < 0:
                    raise OSError("Native encryption update failed")
                return out.raw[:n]
            else:
                return self._encryptor.update(data)

    def encrypt_final(self) -> bytes:
        """Finalize encryption and return the last block of ciphertext."""
        with self._lock:
            if USE_NATIVE:
                out = ctypes.create_string_buffer(16)
                n = _native_lib.aes_encrypt_final(self._ctx_enc, out)
                if n < 0:
                    raise OSError("Native encryption finalization failed")
                return out.raw[:n]
            else:
                return self._encryptor.finalize()

    def encrypt(self, data: bytes) -> bytes:
        """Convenience method: encrypt the entire data block in one call."""
        return self.encrypt_update(data) + self.encrypt_final()

    def decrypt_update(self, data: bytes) -> bytes:
        """Decrypt a chunk of data and return plaintext."""
        if not data:
            return b''
        with self._lock:
            if USE_NATIVE:
                out = ctypes.create_string_buffer(len(data))
                n = _native_lib.aes_decrypt_update(self._ctx_dec, data, len(data), out)
                if n < 0:
                    raise OSError("Native decryption update failed")
                return out.raw[:n]
            else:
                return self._decryptor.update(data)

    def decrypt_final(self) -> bytes:
        """Finalize decryption and return any remaining plaintext."""
        with self._lock:
            if USE_NATIVE:
                out = ctypes.create_string_buffer(16)
                n = _native_lib.aes_decrypt_final(self._ctx_dec, out)
                if n < 0:
                    raise OSError("Native decryption finalization failed")
                return out.raw[:n]
            else:
                return self._decryptor.finalize()

    def decrypt(self, data: bytes) -> bytes:
        """Convenience method: decrypt the entire data block in one call."""
        return self.decrypt_update(data) + self.decrypt_final()