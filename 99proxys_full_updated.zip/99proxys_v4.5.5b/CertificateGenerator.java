// CertificateGenerator.java
//
// A simple Java utility to generate a self‑signed certificate and
// corresponding private key.  It uses the built‑in Java security
// libraries (no external dependencies) to create an RSA key pair,
// build an X509 certificate, and write them to files.  In a
// real‑world scenario you might use BouncyCastle for more
// flexibility.

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Date;
import javax.security.auth.x500.X500Principal;

public class CertificateGenerator {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: java CertificateGenerator <certFile> <keyFile>");
            System.exit(1);
        }
        String certFile = args[0];
        String keyFile  = args[1];
        KeyPairGenerator kpGen = KeyPairGenerator.getInstance("RSA");
        kpGen.initialize(2048);
        KeyPair pair = kpGen.generateKeyPair();
        PrivateKey privKey = pair.getPrivate();
        X500Principal subject = new X500Principal("CN=99Proxys,O=BGGremlin,C=US");
        long now = System.currentTimeMillis();
        Date notBefore = new Date(now - 1000L * 60 * 60);
        Date notAfter  = new Date(now + 1000L * 60 * 60 * 24 * 365);
        BigInteger serial = new BigInteger(64, new SecureRandom());
        // Build certificate using Java's CertificateBuilder (Java 9+ API)
        javax.security.cert.X509Certificate cert;
        try {
            // For demonstration, we use the deprecated API; a modern
            // implementation should use BouncyCastle or the new
            // CertificateBuilder API available in newer JDKs.
            sun.security.x509.X500Name x500Name = new sun.security.x509.X500Name(subject.getName());
            sun.security.x509.X509CertInfo info = new sun.security.x509.X509CertInfo();
            info.set("version", new sun.security.x509.CertificateVersion(sun.security.x509.CertificateVersion.V3));
            info.set("serialNumber", new sun.security.x509.CertificateSerialNumber(serial));
            info.set("subject", new sun.security.x509.CertificateSubjectName(x500Name));
            info.set("issuer", new sun.security.x509.CertificateIssuerName(x500Name));
            info.set("validity", new sun.security.x509.CertificateValidity(notBefore, notAfter));
            info.set("key", new sun.security.x509.CertificateX509Key(pair.getPublic()));
            info.set("algorithmID", new sun.security.x509.CertificateAlgorithmId(
                    new sun.security.x509.AlgorithmId(
                            sun.security.x509.AlgorithmId.sha256WithRSAEncryption_oid)));
            // Sign the certificate
            sun.security.x509.X509CertImpl certImpl = new sun.security.x509.X509CertImpl(info);
            certImpl.sign(privKey, "SHA256withRSA");
            // Write certificate
            try (FileOutputStream fos = new FileOutputStream(certFile)) {
                fos.write(certImpl.getEncoded());
            }
            // Write private key in PEM format
            String pemKey = java.util.Base64.getMimeEncoder(64, "\n".getBytes())
                    .encodeToString(privKey.getEncoded());
            try (FileWriter writer = new FileWriter(keyFile)) {
                writer.write("-----BEGIN PRIVATE KEY-----\n");
                writer.write(pemKey);
                writer.write("\n-----END PRIVATE KEY-----\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}