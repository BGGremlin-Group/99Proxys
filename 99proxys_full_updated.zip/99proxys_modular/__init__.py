"""
99Proxys Modular Package
========================

This package organizes the 99Proxys project into separate modules to
facilitate testing, extension and integration.  It includes the
original proxy implementation in `proxy_core.py`, a standalone
Tor‑emulation module in `tor_emulation.py`, and a lightweight entry
script `main.py` that delegates execution to the core proxy code.

Modules:
    proxy_core.py
        Contains the full original 99Proxys implementation, including
        CLI, GUI, proxy nodes, hidden services and website tooling.

    tor_emulation.py
        Provides a self‑contained onion routing framework for building
        circuits of simulated nodes with layered AES encryption.

    main.py
        Simple wrapper script that executes the core implementation.

You can run the proxy network by executing `python -m 99proxys_modular`
or `python 99proxys_modular/main.py`.  To experiment with onion
routing, import `tor_emulation` directly:

    from 99proxys_modular.tor_emulation import CircuitManager, TorNode

"""