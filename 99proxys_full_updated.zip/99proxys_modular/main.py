"""
99Proxys Modular Entry Point
----------------------------

This script serves as a thin wrapper around the original 99Proxys
implementation.  It forwards all command‑line arguments to
`proxy_core.py` and executes it in a subprocess.  Running this
module allows you to keep the core implementation separate from
auxiliary modules while maintaining the same user experience.

Example:

    python -m 99proxys_modular --cli

will launch the command‑line interface just as if you had run
`python 99proxys_v4-5b.py --cli` directly.
"""

import os
import sys
import subprocess


def main() -> None:
    """Execute the original 99Proxys implementation with forwarded args."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    core_script = os.path.join(current_dir, 'proxy_core.py')
    # Use the same Python interpreter to run the core script
    cmd = [sys.executable, core_script] + sys.argv[1:]
    subprocess.run(cmd, check=True)


if __name__ == '__main__':
    main()